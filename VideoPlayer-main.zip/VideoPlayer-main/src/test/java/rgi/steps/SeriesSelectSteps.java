package rgi.steps;

import static org.junit.Assert.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SeriesSelectSteps {
	
	private String browser = "chrome";
	
	private static WebDriver driver;
	
	@Given("the user is on the home page")
	public void the_user_is_on_the_home_page() {
		if(browser.equals("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();			
		} else if (browser.equals("edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		}
		driver.navigate().to("http://localhost:4200/");
	}

	@Given("clicks on the image of a series")
	public void clicks_on_the_image_of_a_series() {
		driver.findElement(By.xpath("/html/body/app-root/app-landing/div/div/div[2]/img")).click();
	}

	@Then("they should be redirected to the series page;")
	public void they_should_be_redirected_to_the_series_page() {
	   String text = driver.findElement(By.xpath("/html/body/app-root/app-series-view/div/div[1]/div/p")).getText();
	   assertTrue(text.contains("Code Gaess"));
	}

}
