package rgi.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import rgi.models.Series;
import rgi.models.Video;

@TestMethodOrder(value = MethodOrderer.OrderAnnotation.class)
class VideoControllerTest extends AbstractTest {
	
	String vUri = "/videos";
	
	int video_id = 9999;
	int series_id = 999;
	
	List<Video> list = new ArrayList<Video>();
	//Series lSeries = new Series(999,"series name",list, "series img url");
	
//	List<Video> list = new ArrayList<Video>();
//	Series lSeries = new Series(999,"series name",list, "series img url");
//	Series nSeries = new Series(999,"series name",null, "series img url");
//	Series series = new Series();
	

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	protected void setUp() {
		super.setUp();
		// series.setSeries_id(999);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	
	//************************************************************
	//*********************  Videos  *****************************
	//************************************************************
	
	@Test
	@Order(2)
	@DisplayName("*** Test Save New Video ***")
	void testSaveVideo() throws Exception {
		
		Series series1 = new Series(1212, "s1", "pop");
		Series series2 = new Series(1213, "s2", "romantic");
		
		Video video = new Video(video_id,"video url","video name",series1,"video season");
		//lSeries.addEpisode(video);
		
		String videoJson = super.mapToJson(video);
		
		System.out.println("Video JSON :"+videoJson);
		
		MvcResult mvcRS = mockMvc.perform(MockMvcRequestBuilders.post(vUri)
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(videoJson)).andReturn();
		
		int status = mvcRS.getResponse().getStatus();
		String content = mvcRS.getResponse().getContentAsString();
		
		assertEquals(201,status);
		assertEquals(content,"Video did save");
	}
	
	// Change status number, Mock object, String content, and post method to put
	
	/*
	 * @Test
	 * 
	 * @Order(3)
	 * 
	 * @DisplayName("*** Test Update Video ***") void testUpdateVideo() throws
	 * Exception { Video video = new
	 * Video(video_id,"new video url"," new video name", lSeries,
	 * " new video season");
	 * 
	 * String videoJson = super.mapToJson(video);
	 * 
	 * MvcResult mvcRS = mockMvc.perform(MockMvcRequestBuilders.put(vUri)
	 * .contentType(MediaType.APPLICATION_JSON_VALUE)
	 * .content(videoJson)).andReturn();
	 * 
	 * int status = mvcRS.getResponse().getStatus(); String content =
	 * mvcRS.getResponse().getContentAsString();
	 * 
	 * assertEquals(201,status); assertEquals(content,"Video updated successfully");
	 * }
	 */
	@Test
	@Order(5)
	@DisplayName("*** Test Get All Videos Method ***")
	void testGetAllVideos() throws Exception {
		MvcResult mvcRS = mockMvc.perform(MockMvcRequestBuilders.get(vUri)
				.contentType(MediaType.APPLICATION_JSON_VALUE))	
				.andReturn();
		
		int status = mvcRS.getResponse().getStatus();
		String content = mvcRS.getResponse().getContentAsString();
		Video[] returnedVideos = super.mapFromJson(content, Video[].class);
		
		assertEquals(200,status);
		assertTrue(returnedVideos.length > 0);
	}
	
	@Test
	@Order(4)
	@DisplayName("*** Test to Get Video By Id ***")
	void testGetVideoById() throws Exception {
		MvcResult mvcRS = mockMvc.perform(MockMvcRequestBuilders.get(vUri + "/" + video_id)
				.contentType(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		
		int status = mvcRS.getResponse().getStatus();
		String content = mvcRS.getResponse().getContentAsString();
		
		Video video = super.mapFromJson(content, Video.class);
		
		assertEquals(200,status);
		assertEquals(video_id, video.getVideoId());
		
	}
	
	@Test
	@Order(6)
	@DisplayName("*** Test to get Videos By Series ***")
	void testGetVideosBySeries() {
		fail(" Not yet implemented");
	}
	
	@Test
	@Order(7)
	@DisplayName("*** Test to delete video ***")
	void testDeleteVideo() throws Exception {
		Video video = new Video(video_id,"video url","video name", null, "video season");
		MvcResult mvcRS = mockMvc.perform(MockMvcRequestBuilders.delete(vUri + "/" + video_id)
				.contentType(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		
		int status = mvcRS.getResponse().getStatus();
		String content = mvcRS.getResponse().getContentAsString();
		
		assertEquals(200, status);
		assertEquals(content,"Product with id: " + video_id + " was deleted");
	}
	
	
	

}
