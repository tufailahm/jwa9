package rgi.services;

import java.util.List;

import rgi.models.Series;
import rgi.models.Video;

public interface SeriesService {
	
	public String saveSeries(Series series);
	
	public String updateSeries(Series series);
	
	public String deleteSeries(int seriesId);
	
	public Series getSeriesById(int series_id);
	
	public List<Series> getAllSeries();

	public boolean ifSeriesExists(int series_id);

}
