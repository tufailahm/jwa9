package rgi.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rgi.dao.SeriesDao;
import rgi.models.Series;
import rgi.models.Video;

@Service
public class SeriesServiceImpl implements SeriesService {
	
	@Autowired
	SeriesDao sDao;

	@Override
	public List<Series> getAllSeries() {
		// TODO Auto-generated method stub
		return sDao.findAll();
	}

	@Override
	public Series getSeriesById(int series_id) {
		// TODO Auto-generated method stub
		return sDao.getById(series_id);
	}

	@Override
	public String saveSeries(Series series) {
		// TODO Auto-generated method stub
		if(series.getSeries_name().length() < 1) {
			return "Video Name cannot be null";
		} else {
			sDao.save(series);
			return "Series did save";
		}
	}

	@Override
	public String updateSeries(Series series) {
		// TODO Auto-generated method stub
		if(series.getSeries_name().length() < 1) {
			return "Video Name cannot be null";
		} else {
			sDao.save(series);
			return "Video updated successfully";
		}
	}

	@Override
	public String deleteSeries(int seriesId) {
		// TODO Auto-generated method stub
		sDao.deleteById(seriesId);
		return "Product with id: " + seriesId + " was deleted";
	}

	@Override
	public boolean ifSeriesExists(int series_id) {
		// TODO Auto-generated method stub
		Optional<Series> series = sDao.findById(series_id);
		return series.isPresent();
	}

}
