package rgi.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rgi.dao.VideoDao;
import rgi.models.Video;

@Service
public class VideoServiceImpl implements VideoService {
	
	@Autowired
	private VideoDao vDao;


	@Override
	public String saveVideo(Video video) {
		// TODO Auto-generated method stub
		if(video.getVideoName().length() < 1) {
			return "Video Name cannot be null";
		} else {
			vDao.save(video);
			return "Video did save";
		}
		
	}

	@Override
	public String updateVideo(Video video) {
		// TODO Auto-generated method stub
		if(video.getVideoName().length() < 1) {
			return "Video Name cannot be null";
		} else {
			vDao.save(video);
			return "Video updated successfully";
		}
	}

	@Override
	public String deleteVideo(int videoId) {
		// TODO Auto-generated method stub
		vDao.deleteById(videoId);
		return "Product with id: " + videoId + " was deleted";
	}
	
	@Override
	public Video getVideoById(int id) {
		// TODO Auto-generated method stub
		return vDao.getById(id);
	}
	
	@Override
	public List<Video> getAllVideos() {
		// TODO Auto-generated method stub
		return vDao.findAll();
	}

	@Override
	public List<Video> getVideosBySeries(int videoSeriesId) {
		// TODO Auto-generated method stub
		//return vDao.findByVideoSeriesId(videoSeriesId);
		return vDao.getVideosBySeries(videoSeriesId);
	}

	@Override
	public boolean ifVideoExists(int video_id) {
		// TODO Auto-generated method stub
		Optional<Video> video = vDao.findById(video_id);
		return video.isPresent();
	}
}
