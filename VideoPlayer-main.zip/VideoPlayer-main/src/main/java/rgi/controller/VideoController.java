package rgi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import rgi.models.Series;
import rgi.models.Video;
import rgi.services.SeriesService;
import rgi.services.VideoService;

@RestController
@RequestMapping(path="videos")
@CrossOrigin(origins = "http://localhost:4200")
public class VideoController {
	
	@Autowired
	private VideoService vService;
	
	@PostMapping
	public ResponseEntity<String> saveVideo(@RequestBody Video video){
		
		ResponseEntity<String> re = null;
		String result = null;
		
		if(vService.ifVideoExists(video.getVideoId())) {
			// failed
			re = new ResponseEntity<String>("Video already existss", HttpStatus.CONFLICT); // 409
		} else {
			// success
			result = vService.saveVideo(video);
			if(result.equals("Video did save")) {
				re = new ResponseEntity<String>(result,HttpStatus.CREATED); // 201
			} else {
				re = new ResponseEntity<String>(result,HttpStatus.NOT_ACCEPTABLE); // 406
			}
		}
		
		return re;
		
	}
	
	@PutMapping
	public ResponseEntity<String> updateVideo(@RequestBody Video video){
		
		ResponseEntity<String> re = null;
		String result = null;
		
		if(!vService.ifVideoExists(video.getVideoId())) {
			// failed
			re = new ResponseEntity<String>("No Video to Update",HttpStatus.NO_CONTENT); // 204
		} else {
			// success
			result = vService.updateVideo(video);
			if(result.equals("Video updated successfully")) {
				re = new ResponseEntity<String>(result,HttpStatus.OK); // 200
			} else {
				re = new ResponseEntity<String>(result,HttpStatus.NOT_ACCEPTABLE); // 406
			}
		}
		
		return re;
	}
		
	@GetMapping(produces = "application/json")
	public ResponseEntity<List<Video>> getAllVideos() {
		
		ResponseEntity<List<Video>> re = null;
		List<Video> videoList = vService.getAllVideos();
		
		if(videoList.size() == 0) {
			re = new ResponseEntity<List<Video>>(videoList,HttpStatus.NO_CONTENT); // 204
		} else {
			re = new ResponseEntity<List<Video>>(videoList,HttpStatus.OK); // 200
		}
		
		return re;
	}

	@GetMapping(path="{id}", produces = "application/json")
	public ResponseEntity<Video> getVideoById(@PathVariable("id")int id){
		
		ResponseEntity<Video> re = null;
		Video video = vService.getVideoById(id);
		
		if(!vService.ifVideoExists(id)) {
			re = new ResponseEntity<Video>(video,HttpStatus.NOT_FOUND); // 404
		} else {
			re = new ResponseEntity<Video>(video,HttpStatus.OK); // 200
		}
		
		return re;
	}
	
	@GetMapping(path="series/{series_id}", produces="application/json")
	public ResponseEntity<List<Video>> getVideosBySeries(@PathVariable("series_id")int videoSeriesId){
		
		ResponseEntity<List<Video>> re = null;
		List<Video> videoList = vService.getVideosBySeries(videoSeriesId);
		
		if(videoList.size() == 0) {
			re = new ResponseEntity<List<Video>>(videoList, HttpStatus.NO_CONTENT); // 204
		} else {
			re = new ResponseEntity<List<Video>>(videoList, HttpStatus.OK); // 200
		}
		
		return re;
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteVideo(@PathVariable("id}")int id){
		
		ResponseEntity<String> re = null;
		String result=null;
		
		if(!vService.ifVideoExists(id)) {
			// failed
			re= new ResponseEntity<String>(result,HttpStatus.NOT_FOUND); // 404
		} else {
			result = vService.deleteVideo(id);
			if(result.equals("Product with id: " + id + " was deleted")) {
				re = new ResponseEntity<String>(result,HttpStatus.OK); // 200
			} else {
				re = new ResponseEntity<String>(result,HttpStatus.NOT_ACCEPTABLE); // 406
			}
		}
		
		return re;
	}
	
}
