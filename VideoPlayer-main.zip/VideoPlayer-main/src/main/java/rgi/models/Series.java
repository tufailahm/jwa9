package rgi.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "series")
@Entity
public class Series {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="series_id")
	private int series_id;
	
	@Column(name="series_name")
	private String series_name;
	
	/*
	 * //@JsonIgnore
	 * 
	 * @JsonBackReference
	 * 
	 * @OneToMany(mappedBy="videoSeriesId", cascade=CascadeType.ALL, fetch =
	 * FetchType.LAZY) private List<Video> series_episodes = new ArrayList<Video>();
	 */
	
	@Column(name="series_img")
	private String series_img;
	
	/*
	 * public void addEpisode(Video video) { series_episodes.add(video); }
	 * 
	 * public void removeEpisode(Video video) { series_episodes.remove(video); }
	 */
}
