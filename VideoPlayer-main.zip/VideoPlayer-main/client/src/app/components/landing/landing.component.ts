import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Series } from 'src/app/models/series';
import { SeriesService } from 'src/app/services/series.service';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.css']
})
export class LandingComponent implements OnInit {

  allSeries:any = [];

  constructor(private seriesService:SeriesService, private router:Router) { }

  ngOnInit(): void {
    this.getAllVideos();
  }

  getAllVideos(){
    this.seriesService.getAllSeries().subscribe(
      (data) => {
        this.allSeries = data;
        this.sortSeriesByName();
      }
    )
  }

  sortSeriesByName(){
    this.allSeries.sort((a:any,b:any)=> {
      let fa = a.series_name.toLowerCase(),fb = b.series_name.toLowerCase();

      if (fa<fb){
        return -1;
      }
      if (fa>fb) {
        return 1;
      }
      return 0;
    })
  }

  onClick(series:Series){
    this.seriesService.setCurrentSeries(series);
    this.router.navigate([`series/${series.series_id}`]);
  }

}
