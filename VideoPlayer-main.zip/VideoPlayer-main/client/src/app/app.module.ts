import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { VideoService } from './services/video.service';
import { LandingComponent } from './components/landing/landing.component';
import { DetailedViewComponent } from './components/detailed-view/detailed-view.component';
import { AppRoutingModule } from './app-routing/app-routing.module';
import { HttpClient,HttpClientModule,HttpHandler } from '@angular/common/http';
import { SeriesService } from './services/series.service';
import { SeriesViewComponent } from './components/series-view/series-view.component';

@NgModule({
  declarations: [
    AppComponent,
    LandingComponent,
    DetailedViewComponent,
    SeriesViewComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [HttpClient,VideoService,SeriesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
