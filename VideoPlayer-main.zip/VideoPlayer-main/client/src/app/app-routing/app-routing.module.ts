import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DetailedViewComponent } from '../components/detailed-view/detailed-view.component';
import { LandingComponent } from '../components/landing/landing.component';
import { SeriesViewComponent } from '../components/series-view/series-view.component';

const routes: Routes = [
{path: '',component: LandingComponent,},
{path: 'series/:id',component: SeriesViewComponent},
{path: 'series/:id/:episode',component: DetailedViewComponent}
];

@NgModule({
imports: [
RouterModule.forRoot(routes)
],
exports: [
RouterModule
],
declarations: []
})
export class AppRoutingModule { }
