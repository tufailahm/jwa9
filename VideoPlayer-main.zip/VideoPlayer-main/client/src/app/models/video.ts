export class Video {

    constructor (
        public video_id:number,
        public video_url:String,
        public video_name:String,
        public video_series:String,
        public video_series_img:String,
        public video_season:String
    ) {}
    
}
