export class Series {

    constructor (
        public series_id:number,
        public series_name:String,
        public series_episodes:String[],
        public series_img:String
    ) {}
}
