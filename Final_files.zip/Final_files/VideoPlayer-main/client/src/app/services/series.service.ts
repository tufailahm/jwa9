import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Series } from '../models/series';
import { Video } from '../models/video';

@Injectable({
  providedIn: 'root'
})
export class SeriesService {

  private url="http://localhost:9999/";
  public seriesArray:any;
  public currentSeries:any;
  public currentEpisode:any;

  constructor(private http:HttpClient) {
    this.seriesArray = this.getAllSeries();
  }

  public getAllSeries(): Observable<Series[]>{
    return this.http.get(`${this.url}series`) as Observable<Series[]>;
  }

  public setCurrentEpisode(episode:Video){
    this.currentEpisode = episode;
  }

  public getCurrentEpisode(){
    return this.currentEpisode;
  }

  public setCurrentSeries(series:Series){
    this.currentSeries = series;
  }

  public getCurrentSeries(){
    return this.currentSeries;
  }
}
