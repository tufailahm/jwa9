import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Video } from '../models/video';

@Injectable({
  providedIn: 'root'
})
export class VideoService {

  public currentEpisode:any = [];

  private url="http://localhost:9999/videos";

  constructor(private http: HttpClient) { 
  }

  public getAllVideos(): Observable<Video[]>{
    return this.http.get(`${this.url}`) as Observable<Video[]>;
  }

  public getVideosBySeries(series:any): Observable<Video[]>{
    return this.http.get(`${this.url}/series/${series.series_id}`) as Observable<Video[]>;
  }

  public getVideoById(episode:any) {
    this.http.get(`${this.url}/${episode.video_id}`).subscribe(
      (data) => {
        this.currentEpisode = data;
      }
    )
  }

}
