import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Series } from 'src/app/models/series';
import { SeriesService } from 'src/app/services/series.service';
import { VideoService } from 'src/app/services/video.service';

@Component({
  selector: 'app-series-view',
  templateUrl: './series-view.component.html',
  styleUrls: ['./series-view.component.css']
})
export class SeriesViewComponent implements OnInit {

  currentSeries:any = [];
  currentSeriesEpisodes:any = [];

  constructor(private sService: SeriesService, private vService: VideoService,private router: Router) { }

  ngOnInit(): void {
    this.getSelectedSeries();
    this.getEpisodesOfSeries();
  }

  getSelectedSeries(){
    this.currentSeries = this.sService.getCurrentSeries();
  }

  getEpisodesOfSeries(){
    console.log(this.currentSeries);
    this.vService.getVideosBySeries(this.currentSeries).subscribe(
      (data) => {
        this.currentSeriesEpisodes = data;
        console.log(this.currentSeriesEpisodes);
      }
    );
  }

  episodeClick(episode:any){
    this.sService.setCurrentEpisode(episode);
    this.router.navigate([`series/${this.currentSeries.series_id}/${episode.video_id}`])
  }

}
