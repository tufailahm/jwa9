import { Component, OnInit } from '@angular/core';
import { SeriesService } from 'src/app/services/series.service';
import { VideoService } from 'src/app/services/video.service';

@Component({
  selector: 'app-detailed-view',
  templateUrl: './detailed-view.component.html',
  styleUrls: ['./detailed-view.component.css']
})
export class DetailedViewComponent implements OnInit {

  episode:any = [];

  constructor(private seriesService:SeriesService) { }

  ngOnInit(): void {
    this.getCurrentEpisode();
  }

  getCurrentEpisode() {
    this.episode = this.seriesService.getCurrentEpisode();
  }
}
