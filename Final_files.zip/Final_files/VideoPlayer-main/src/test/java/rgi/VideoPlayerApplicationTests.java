package rgi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideoPlayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
