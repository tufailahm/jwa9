package rgi.steps;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DatabaseTestSteps {
	
	Connection conn = null;
	ResultSet rs = null;
	
	@When("a connection is esablished with {string} {string} {string} and {string}")
	public void a_connection_is_esablished_with_and(String string, String string2, String string3, String string4) throws ClassNotFoundException, SQLException {
	    Class.forName(string2);
	    conn = DriverManager.getConnection(string, string3, string4);
	}

	@When("we execute a query to get {string} from {string} where {string} to get {int}")
	public void we_execute_a_query_to_get_from_where_to_get(String string, String string2, String string3, Integer int1) throws SQLException {
	    String query = "SELECT " + string + " FROM " + string2 + " WHERE " + string3 + " = " + int1;
	    Statement stat = conn.createStatement();
	    rs = stat.executeQuery(query);
	}

	@Then("we should see the result as {string}")
	public void we_should_see_the_result_as(String string) throws SQLException {
	    rs.next();
	    String expected = string;
	    String actual = rs.getString(1);
	    assertEquals(expected,actual);
	}

}
