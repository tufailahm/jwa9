package rgi.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import rgi.models.Series;
import rgi.models.Video;

@TestMethodOrder(value = MethodOrderer.OrderAnnotation.class)
class SeriesControllerTest extends AbstractTest {
	
	String sUri = "/series";
	int series_id = 999;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	protected void setUp() {
		super.setUp();
	}

	@AfterEach
	void tearDown() throws Exception {
	}
	
	@Test
	@Order(1)
	@DisplayName("*** Test Save New Series ***")
	void testSaveSeries() throws Exception {
		List<Video> list = new ArrayList<Video>();
		Series series = new Series(series_id, "series name", list, "series img url");
		
		String seriesJson = super.mapToJson(series);
		
		MvcResult mvcRS = mockMvc.perform(MockMvcRequestBuilders.post(sUri)
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.content(seriesJson)).andReturn();
		
		int status = mvcRS.getResponse().getStatus();
		String content = mvcRS.getResponse().getContentAsString();
		
		assertEquals(200,status);
		assertEquals(content,"Series did save");
	}
	
	@Test
	@Order(8)
	@DisplayName("*** Test to delete Series ***")
	void testDeleteSeries() throws Exception {
		MvcResult mvcRS = mockMvc.perform(MockMvcRequestBuilders.delete(sUri + "/" + series_id)
				.contentType(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		
		int status = mvcRS.getResponse().getStatus();
		String content = mvcRS.getResponse().getContentAsString();
		
		assertEquals(200, status);
		assertEquals(content,"Series with id: " + series_id + " was deleted");
	}

	@Test
	void testGetAllSeries() throws Exception {
		MvcResult mvcRS = mockMvc.perform(MockMvcRequestBuilders.get(sUri)
				.contentType(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();
		
		int status = mvcRS.getResponse().getStatus();
		String content = mvcRS.getResponse().getContentAsString();
		
		Series[] series = super.mapFromJson(content, Series[].class);
		
		assertEquals(200,status);
		assertTrue(series.length > 0);
	}

}
