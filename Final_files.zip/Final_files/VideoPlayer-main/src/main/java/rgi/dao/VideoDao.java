package rgi.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import rgi.models.Video;

@Repository
public interface VideoDao extends JpaRepository<Video, Integer>{

	@Query(value = "Select * from videoplayer.videos where video_series_id = ?1", nativeQuery = true)
	List<Video> getVideosBySeries(int series_id);
	
	List<Video> findByVideoSeriesId(int videoSeriesID);
}