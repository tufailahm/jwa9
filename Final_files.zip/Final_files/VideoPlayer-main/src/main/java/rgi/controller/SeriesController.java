package rgi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import rgi.models.Series;
import rgi.models.Video;
import rgi.services.SeriesService;

@RestController
@RequestMapping(path="series")
@CrossOrigin(origins = "http://localhost:4200")
public class SeriesController {
	
	@Autowired
	private SeriesService sService;
	
	
	@PostMapping
	public ResponseEntity<String> saveSeries(@RequestBody Series series){
		
		ResponseEntity<String> re = null;
		String result = null;
		
		if(sService.ifSeriesExists(series.getSeries_id())) {
			// failed
			re = new ResponseEntity<String>("Video already existss", HttpStatus.CONFLICT); // 409
		} else {
			// success
			result = sService.saveSeries(series);
			if(result.equals("Series did save")) {
				re = new ResponseEntity<String>(result,HttpStatus.CREATED); // 201
			} else {
				re = new ResponseEntity<String>(result,HttpStatus.NOT_ACCEPTABLE); // 406
			}
		}
		
		return re;
		
	}
	
	@PutMapping
	public ResponseEntity<String> updateSeries(@RequestBody Series series){
		
		ResponseEntity<String> re = null;
		String result = null;
		
		if(!sService.ifSeriesExists(series.getSeries_id())) {
			// failed
			re = new ResponseEntity<String>("No Video to Update",HttpStatus.NO_CONTENT); // 204
		} else {
			// success
			result = sService.updateSeries(series);
			if(result.equals("Video updated successfully")) {
				re = new ResponseEntity<String>(result,HttpStatus.OK); // 200
			} else {
				re = new ResponseEntity<String>(result,HttpStatus.NOT_ACCEPTABLE); // 406
			}
		}
		
		return re;
	}
	
	@GetMapping(path="{id}", produces = "application/json")
	public ResponseEntity<Series> getSeriesById(@PathVariable("id")int id){
		
		ResponseEntity<Series> re = null;
		Series series = sService.getSeriesById(id);
		
		if(!sService.ifSeriesExists(id)) {
			re = new ResponseEntity<Series>(series,HttpStatus.NOT_FOUND); // 404
		} else {
			re = new ResponseEntity<Series>(series,HttpStatus.OK); // 200
		}
		
		return re;
	}
	
	@GetMapping(produces="application/json")
	public ResponseEntity<List<Series>> getAllSeries(){
		
		ResponseEntity<List<Series>> re = null;
		List<Series> seriesList = sService.getAllSeries();
		
		if(seriesList.size() == 0) {
			re = new ResponseEntity<List<Series>>(seriesList,HttpStatus.NO_CONTENT); // 204
		} else {
			re = new ResponseEntity<List<Series>>(seriesList,HttpStatus.OK); // 200
		}
		return re;
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<String> deleteSeries(@PathVariable("id}")int id){
		
		ResponseEntity<String> re = null;
		String result=null;
		
		if(!sService.ifSeriesExists(id)) {
			// failed
			re= new ResponseEntity<String>(result,HttpStatus.NOT_FOUND); // 404
		} else {
			result = sService.deleteSeries(id);
			if(result.equals("Series with id: " + id + " was deleted")) {
				re = new ResponseEntity<String>(result,HttpStatus.OK); // 200
			} else {
				re = new ResponseEntity<String>(result,HttpStatus.NOT_ACCEPTABLE); // 406
			}
		}
		
		return re;
	}
	
	
}
