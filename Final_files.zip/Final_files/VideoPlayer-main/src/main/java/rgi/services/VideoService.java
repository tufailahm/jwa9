package rgi.services;

import java.util.List;

import rgi.models.Video;

public interface VideoService {
	
	public String saveVideo(Video video);
	
	public String updateVideo(Video video);
	
	public String deleteVideo(int videoId);
	
	public Video getVideoById(int id);
	
	public List<Video> getAllVideos();
	
	public List<Video> getVideosBySeries(int series_id);
	
	public boolean ifVideoExists(int video_id);

}
