package com.training.jwa;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

class CalculatorTest {

	
	@Test
	@DisplayName(value = "testing sum of whole numbers")
	void testSum1() {
		Calculator calculator = new Calculator();
		int expected=20;
		int actual = calculator.sum(10, 10);
		assertEquals(expected, actual);
		
	}
	
	@Test
	@DisplayName(value = "testing sum of negative and whole numbers")
	void testSum2() {
		Calculator calculator = new Calculator();
		int expected=20;
		int actual = calculator.sum(40,-20);
		assertEquals(expected, actual);
	}


}
