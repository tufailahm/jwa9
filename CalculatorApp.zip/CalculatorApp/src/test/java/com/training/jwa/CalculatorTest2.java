package com.training.jwa;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(value = MethodOrderer.OrderAnnotation.class)
class CalculatorTest2 {

	Calculator calculator;
	int expected;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("###All the tests are getting started");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("###All the tests completed. Please check the logs for more details");

	}

	@BeforeEach
	void setUp() throws Exception {
		calculator = new Calculator();
		expected =20;
	}

	@AfterEach
	void tearDown() throws Exception {
		calculator = null;
		expected =0;
	}

	@Test
	@Order(1)
	@DisplayName(value = "1. testing sum of whole number and a negative number")
	void testSum() {
		int actual = calculator.sum(40,-20);
		assertEquals(expected, actual);
	}

	@Test
	@Order(4)
	@DisplayName(value = "4. testing multiple of whole numbers")
	void testMultiply() {
		int actual = calculator.multiply(2,10);
		assertEquals(expected, actual);
	}

	@Test
	@Order(2)
	@DisplayName(value = "2. testing substraction of whole numbers")
	void testSubstract() {
		int actual = calculator.substract(40,20);
		assertEquals(expected, actual);
	}

	@Test
	@Order(3)
	@DisplayName(value = "3.testing sum of whole numbers")
	void testSum2() {
		int actual = calculator.sum(10,10);
		assertEquals(expected, actual);
	}
	
	@Test
	@DisplayName(value = "10.testing sum of whole numbers")
	void testSum3() {
		int actual = calculator.sum(5,15);
		assertEquals(expected, actual);
	}
}
